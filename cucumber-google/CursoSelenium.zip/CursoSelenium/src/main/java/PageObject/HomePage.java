package PageObject;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import static com.codeborne.selenide.Selenide.$;
import org.openqa.selenium.By;

public class HomePage {

    //Locators
    public static SelenideElement login() {
        return $(By.className("login"));
    }

    //Locators -> Signin
    public static SelenideElement emailField() {
        return $(By.id("email"));
    }

    public static SelenideElement passwordField() {
        return $(By.id("passwd"));
    }

    public static SelenideElement submitButton() {
        return $(By.id("SubmitLogin"));
    }

    public static SelenideElement errorMessage() {
        return $(By.cssSelector("#center_column > div.alert.alert-danger"));
    }

    //Locators my account

    public static SelenideElement myAccountInfo() {
        return $(By.cssSelector("#center_column > h1"));
    }

    //Actions
    public static void goToSignForm() {
        HomePage.login().click();
    }

    public static SelenideElement signOutButton() {
        return $(By.className("logout"));
    }

    //Signin actions -> posteriormente refactor
    public static void fillLoginForm(String email, String password) {
        setEmail(email);
        setPassword(password);
        clickSubmit();
    }

    private static void clickSubmit() {
        submitButton().click();
    }

    private static void setPassword(String password) {
        passwordField().sendKeys(password);
    }

    private static void setEmail(String email) {
        emailField().sendKeys(email);
    }

    public static String getErrorMessage() {
        return errorMessage().toString();
    }

    public static String getMyAccountText() {
        return HomePage.myAccountInfo().getText();
    }

    public static void clickSignOutButon() {
        signOutButton().click();
    }
}
