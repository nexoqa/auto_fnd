import com.codeborne.selenide.Configuration;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "classpath:features/",
        glue = "Steps",
        plugin = {"html:build/reports/cucumber/cucumber-reports.html",
                "json:build/reports/cucumber/cucumber.json",
                "pretty"
        },
        tags = "@login2"
)
public class RunCucumberTest {

    @BeforeClass
    public static void setUp() {
        Configuration.startMaximized = true;
        Configuration.browser = "chrome";
        Configuration.headless = false;//-> para entornos de integracion continua JEnkins, gitlab, Circleci.....
    }

}
