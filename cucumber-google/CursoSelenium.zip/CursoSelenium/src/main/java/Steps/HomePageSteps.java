package Steps;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import PageObject.HomePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import static com.codeborne.selenide.Selenide.open;

public class HomePageSteps {

    @Given("I am on the HomePage")
    public void i_am_on_the_homepage() {
        open("http://automationpractice.com/");
    }

    @When("the user fills the login's mandatory fields: {string} and {string}")
    public void the_user_fills_the_login_mandatory_fields(String email, String password){
        HomePage.goToSignForm(); //estoy en la pantalla para introducir credenciales
        HomePage.fillLoginForm(email,password);
    }

    @Then("the ecommerce should be shown an error")
    public void the_ecommder_should_be_shown_an_error() {
        Assert.assertTrue(HomePage.getErrorMessage().contains("Authentication failed."));
    }

    @Then("the user is logged")
    public void the_user_is_logged(){
        HomePage.myAccountInfo().isDisplayed();
        Assert.assertEquals("MY ACCOUNT", HomePage.getMyAccountText());
        HomePage.signOutButton();//-> me aseguro de que el test finaliza como empezó
    }

}
